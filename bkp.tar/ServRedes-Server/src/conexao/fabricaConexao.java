package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class fabricaConexao {

	private static final String URL = "jdbc:postgresql://localhost:5432/SAP";
	private static final String USER = "postgres";
	private static final String PASS = "123456";

	public static Connection open() {
		Connection connect = null;
		try {
			connect = DriverManager.getConnection(URL, USER, PASS);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connect;
	}

	public static void close(Connection Connect, PreparedStatement Statment,
			ResultSet RSet) {
		try {
			if (Connect != null) {
				Connect.close();
			}
			if (Statment != null) {
				Statment.close();
			}
			if (RSet != null) {
				RSet.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
