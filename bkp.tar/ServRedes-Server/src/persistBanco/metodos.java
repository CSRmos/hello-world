package persistBanco;

import org.json.JSONObject;

public class metodos {

	controlaUsuario CU = new controlaUsuario();
	controlaCadastro CC = new controlaCadastro();
	JSONObject resposta = new JSONObject();

	public JSONObject cadastroUsuario(JSONObject json) {
		String matricula = json.getString("Matricula");
		if (CU.checaUsuario(matricula) == true) {
			return resposta.put("Resposta", "5");

		} else {
			CU.inserir(json);
			return resposta.put("Resposta", "4");
		}
	}

	public JSONObject login(JSONObject json) {
		String matricula = json.getString("Matricula");
		
		if (CU.checaUsuario(matricula) == true) {
			if (CU.chechaSenha(matricula,
					json.getString("Senha")) == true) {
				return resposta.put("Resposta", "1");
			} else {
				return resposta.put("Resposta", "3");
			}
		} else {
			return resposta.put("Resposta", "2");
		}
	}

	public JSONObject cadastraItem(JSONObject json) {
		String matricula = json.getString("Matricula");

		if (!matricula.isEmpty()) {
			CC.inserir(json);
			return resposta.put("Resposta", "9");
		} else {
			return resposta.put("Resposta", "10");
		}
	}

	public JSONObject recuperaSenha(JSONObject json) {
		String matricula = json.getString("Matricula");

		if (CU.checaUsuario(matricula) == true) {
			if (CU.recuperaSenha(json.getString("Resposta"),
					json.getInt("PergDeSeg"), matricula) == 0) {
				return resposta.put("Resposta", "8");
			} else {
				return resposta.put(
						"Resposta",
						CU.recuperaSenha(json.getString("Resposta"),
								json.getInt("PergDeSeg"), matricula));
			}
		} else {
			return resposta.put("Resposta", "2");
		}
	}

	public JSONObject listaCadastros() {

		JSONObject resposta = new JSONObject();
		resposta.put("Resposta", CC.listarCadastros());
		return resposta;

	}

	public JSONObject listaPorStatus(JSONObject json) {

		JSONObject resposta = new JSONObject();
		resposta.put("Resposta", CC.listarPorStatus(json.getInt("Status")));
		return resposta;

	}

	public JSONObject listaMeusCadastros(JSONObject json) {

		JSONObject resposta = new JSONObject();
		resposta.put("Resposta",
				CC.listarMeusCadastros(json.getInt("Matricula")));
		return resposta;

	}

	public JSONObject atualizaStatus(JSONObject json) {
		int id = json.getInt("ID");
		if (CC.checaCadastro(id) == true) {
			CC.atualizaStatus(json.getInt("Status"), id,
					json.getInt("Matricula"));
			return resposta.put("Resposta", "6");
		} else if (CC.checaCadastro(id) == false) {
			return resposta.put("Resposta", "7");
		}
		return resposta.put("Resposta", "0");
	}

}
