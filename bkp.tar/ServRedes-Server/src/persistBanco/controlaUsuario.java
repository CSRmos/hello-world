package persistBanco;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONObject;

import conexao.*;

@SuppressWarnings("static-access")
public class controlaUsuario {

	fabricaConexao FC = new fabricaConexao();

	public void inserir(JSONObject json) {
		Connection con = FC.open();
		PreparedStatement ps = null;

		String sql = "INSERT INTO usuario "
				+ "(nomeu, cursou, emailu, resposta, matriculau, senhau, telefoneu, pergunta)"
				+ "VALUES( ?,?,?,?,?,?, ?, ?)";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, json.getString("Nome"));
			ps.setString(2, json.getString("Curso"));
			ps.setString(3, json.getString("Email"));
			ps.setString(4, json.getString("Resposta"));
			ps.setString(5, json.getString("Matricula"));
			ps.setString(6, json.getString("Senha"));
			ps.setString(7, json.getString("Telefone"));
			ps.setString(8, json.getString("Pergunta"));
			ps.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			FC.close(con, ps, null);
		}

	}

	public boolean checaUsuario(String matricula) {
		Connection con = FC.open();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM usuario where matriculau = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, matricula);
			rs = ps.executeQuery();

			int busca = 0;

			while (rs.next()) {

				busca = rs.getInt("matriculau");
			}

			if (busca == 0) {
				return false;
			} else {
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}
		return true;
	}

	public boolean chechaSenha(String matricula, String senha) {

		Connection con = FC.open();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM usuario where matriculau = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, matricula);
			rs = ps.executeQuery();

			String sen = "";

			while (rs.next()) {
				sen = rs.getString("senhau");
				System.out.println(sen);
				System.out.println(senha);
			}

			if (senha.equals(sen)) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}

		return false;
	}

	public int recuperaSenha(String resposta, int pergunta, String matricula) {
		Connection con = FC.open();
		PreparedStatement ps = null;
		ResultSet rs = null;
		int senha = 0;
		try {
			String sql = "	";
			ps = con.prepareStatement(sql);

			ps.setInt(1, pergunta);
			ps.setString(2, matricula);
			ps.setString(3, resposta);
			rs = ps.executeQuery();

			senha = 0;

			while (rs.next()) {
				senha = rs.getInt("senhau");
			}
			return senha;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}

		return senha;
	}

	// public boolean deletarPessoa(Integer CPF) {
	// Usuario pessoa = buscarPessoa(CPF);
	// Connection con = cf.open();
	// PreparedStatement ps = null;
	// if (pessoa != null) {
	// try {
	// String sql = "DELETE FROM pessoa where cpf = ?";
	// ps = con.prepareStatement(sql);
	// ps.setInt(1, CPF);
	// ps.executeUpdate();
	// return true;
	// } catch (SQLException e) {
	// e.printStackTrace();
	// }
	// }
	// return false;
	// }
}