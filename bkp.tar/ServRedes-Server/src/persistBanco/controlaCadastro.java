package persistBanco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONObject;

import conexao.fabricaConexao;

@SuppressWarnings("static-access")
public class controlaCadastro {
	fabricaConexao FC = new fabricaConexao();

	public void inserir(JSONObject json) {
		Connection con = FC.open();
		PreparedStatement ps = null;

		String sql = "INSERT INTO cadastro "
				+ "(tipo, status, locali, datai, item, desci, categoria, matricula)"
				+ "VALUES( ?,?,?,?,?,?,?,?)";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, json.getInt("Tipo"));
			ps.setInt(2, json.getInt("Status"));
			ps.setString(3, json.getString("Local"));
			ps.setString(4, json.getString("Data"));
			ps.setString(5, json.getString("Item"));
			ps.setString(6, json.getString("Descricao"));
			ps.setString(7, json.getString("Categoria"));
			ps.setString(8, json.getString("Matricula"));
			ps.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			FC.close(con, ps, null);
		}

	}

	public JSONArray listarCadastros() {
		Connection con = FC.open();
		JSONArray arrayResposta = new JSONArray();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM cadastro";
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				JSONObject jsonObject = new JSONObject();

				jsonObject.put("ID", rs.getInt("id"));
				jsonObject.put("Matricula", rs.getString("matricula"));
				jsonObject.put("Tipo", rs.getString("tipo"));
				jsonObject.put("Status", rs.getString("status"));
				jsonObject.put("Local", rs.getString("locali"));
				jsonObject.put("Data", rs.getString("datai"));
				jsonObject.put("Descricao", rs.getString("desci"));
				jsonObject.put("Categoria", rs.getString("categoria"));

				arrayResposta.put(jsonObject);
			}

			return arrayResposta;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}
		return null;
	}

	public JSONArray listarPorStatus(int status) {
		Connection con = FC.open();
		JSONArray arrayResposta = new JSONArray();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM cadastro WHERE status = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, status);

			rs = ps.executeQuery();

			while (rs.next()) {
				JSONObject jsonObject = new JSONObject();

				jsonObject.put("ID", rs.getInt("id"));
				jsonObject.put("Matricula", rs.getString("matricula"));
				jsonObject.put("Tipo", rs.getString("tipo"));
				jsonObject.put("Status", rs.getString("status"));
				jsonObject.put("Local", rs.getString("locali"));
				jsonObject.put("Data", rs.getString("datai"));
				jsonObject.put("Descricao", rs.getString("desci"));
				jsonObject.put("Categoria", rs.getString("categoria"));

				arrayResposta.put(jsonObject);
			}

			return arrayResposta;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}
		return null;
	}

	public JSONArray listarMeusCadastros(int matricula) {
		Connection con = FC.open();
		JSONArray arrayResposta = new JSONArray();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM cadastro WHERE matricula = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, matricula);

			rs = ps.executeQuery();

			while (rs.next()) {
				JSONObject jsonObject = new JSONObject();

				jsonObject.put("ID", rs.getInt("id"));
				jsonObject.put("Matricula", rs.getString("matricula"));
				jsonObject.put("Tipo", rs.getString("tipo"));
				jsonObject.put("Status", rs.getString("status"));
				jsonObject.put("Local", rs.getString("locali"));
				jsonObject.put("Data", rs.getString("datai"));
				jsonObject.put("Descricao", rs.getString("desci"));
				jsonObject.put("Categoria", rs.getString("categoria"));

				arrayResposta.put(jsonObject);
			}

			return arrayResposta;

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}
		return null;
	}

	public void atualizaStatus(int status, int id, int matricula) {
		Connection con = FC.open();
		PreparedStatement ps = null;
		try {
			ps = con.prepareStatement("update cadastro set status = ? where id	= ? AND matricula = ?");

			ps.setInt(1, status);
			ps.setInt(2, id);
			ps.setInt(3, matricula);
			ps.executeUpdate();
			ps.close();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, null);
		}
	}

	public boolean checaCadastro(Integer id) {
		Connection con = FC.open();
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			String sql = "SELECT * FROM cadastro where id = ?";
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			int busca = 0;

			while (rs.next()) {

				busca = rs.getInt("id");
			}

			if (busca == 0) {
				return false;
			} else {
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			FC.close(con, ps, rs);
		}
		return true;
	}
}
