package persistBanco;

import org.json.JSONObject;

public class controlaMetodos {
	metodos metodos = new metodos();
	JSONObject json = new JSONObject();
	JSONObject resposta = new JSONObject();

	int flag;

	public JSONObject escolheMetodo(JSONObject pacote) {

		flag = Integer.parseInt(pacote.getString("Flag"));

		if (flag == 0) {
			json = pacote.getJSONObject("Json");
			return metodos.login(json);
		} else if (flag == 1) {
			json = pacote.getJSONObject("Json");
			return metodos.cadastroUsuario(json);
		} else if (flag == 2) {
			json = pacote.getJSONObject("Json");
			return metodos.cadastraItem(json);
		} else if (flag == 3) {
			json = pacote.getJSONObject("Json");
			return metodos.recuperaSenha(json);
		} else if (flag == 4) {
			return metodos.listaCadastros();
		} else if (flag == 5) {
			json = pacote.getJSONObject("Json");
			return metodos.atualizaStatus(json);
		} else if (flag == 6) {
			json = pacote.getJSONObject("Json");
			return metodos.listaPorStatus(json);
		} else if (flag == 7) {
			json = pacote.getJSONObject("Json");
			return metodos.listaMeusCadastros(json);
		} else {
			resposta.put("Resposta", "Nenhum serviço associado!!!");
			return resposta;
		}
	}
}
