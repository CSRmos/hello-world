package teste;

import java.util.Scanner;

import org.json.JSONObject;

import socket.socketCliente;

@SuppressWarnings("resource")
public class clienteTeste {

	public static void main(String[] args) {

		socketCliente SC = new socketCliente();
		String matricula = "";

		System.out.println("Seja Bem Vindo");
		Scanner scan = new Scanner(System.in);
		int opcao = 1;
		while (opcao != 0) {

			System.out.println("\nEscolha a Operacao!!!");
			System.out.println("\t0 -> Sair");
			System.out.println("\t1 -> Login");
			System.out.println("\t2 -> Cadastro de Usuario");
			System.out.println("\t3 -> Cadastro de Item");
			System.out.println("\t4 -> Esqueci minha senha");
			System.out.println("\t5 -> Alterar Status de Cadastro");
			System.out.println("\t6 -> Listar Todos os Cadastros");
			System.out.println("\t7 -> Listar Todos os Cadastros por Status");
			System.out.println("\t8 -> Listar Todos os Meus Cadastros");
			System.out.print("\n-> ");
			opcao = scan.nextInt();

			if (opcao == 0) {
				System.out.println("Bye... ;)");
			} else if (opcao == 1) {
				JSONObject json = new JSONObject();
				JSONObject pacote = new JSONObject();

				System.out.println("\t\t\tLogin");
				System.out.print("Matricula -> ");
				matricula = scan.nextLine();
				matricula = scan.nextLine();
				json.put("Matricula", matricula);
				System.out.print("Senha -> ");
				String senha = scan.nextLine();
				json.put("Senha", senha);

				pacote.put("Json", json);
				pacote.put("Flag", "0");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse());

			} else if (opcao == 2) {
				JSONObject json = new JSONObject();
				JSONObject pacote = new JSONObject();

				System.out.println("Cadastro de Novo Usuario.\n");

				json.put("Nome", "Cleilson Ramos");
				json.put("Curso", "Redes de Computadores");
				json.put("Telefone", "3323423");
				json.put("Matricula", "358367");
				json.put("Resposta", "358367");
				json.put("Pergunta", "358367");
				json.put("Email", "teste@tste");
				json.put("Senha", "425332");

				pacote.put("Json", json);
				pacote.put("Flag", "1");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else if (opcao == 3) {
				JSONObject json = new JSONObject();
				JSONObject pacote = new JSONObject();

				System.out.println("Cadastro de Novo Item.\n");
				
				json.put("Tipo", 1);
				json.put("Status", 1);
				json.put("Local", "Lab 01");
				json.put("Data", "20/02/2016");
				json.put("Item", "Celular");
				json.put("Descricao", "Galaxy S5 cinza");
				json.put("Categoria", "1");
				json.put("Matricula", "358361");

				pacote.put("Json", json);
				pacote.put("Flag", "2");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else if (opcao == 4) {
				JSONObject json = new JSONObject();
				JSONObject pacote = new JSONObject();

				System.out.println("Recuperar Senha.\n");

				json.put("Matricula", "35830");
				json.put("PergDeSeg", "1");
				json.put("Resposta", "ABC122");

				pacote.put("Json", json);
				pacote.put("Flag", "3");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else if (opcao == 6) {
				JSONObject pacote = new JSONObject();

				System.out.println("Lista de todos os cadastros.\n");

				pacote.put("Flag", "4");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else if (opcao == 5) {
				JSONObject pacote = new JSONObject();
				JSONObject json = new JSONObject();

				System.out.println("Atualiza Status de cadastro.");

				json.put("Matricula", "358370");
				json.put("Status", "5");
				json.put("ID", 4);

				pacote.put("Json", json);
				pacote.put("Flag", "5");

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else if (opcao == 7) {
				JSONObject pacote = new JSONObject();
				JSONObject json = new JSONObject();

				json.put("Status", 0);

				System.out.println("Lista de todos os cadastros por status "
						+ json.getInt("Status") + "\n");

				pacote.put("Json", json);
				pacote.put("Flag", "6");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else if (opcao == 8) {
				JSONObject pacote = new JSONObject();
				JSONObject json = new JSONObject();

				json.put("Matricula", 358374);

				System.out.println("Lista de todos os cadastros do Usuario de matricula"
						+ json.getInt("Matricula") + "\n");

				pacote.put("Json", json);
				pacote.put("Flag", "7");

				System.out.println("Enviado: " + pacote.toString());

				SC.sendRequest(pacote);
				System.out.println("Recebido: " + SC.getResponse().toString());

			} else {
				System.out.println("Opcao Invalida!!!");
			}

		}
	}

}
