package socket;

import java.net.*;
import java.io.*;
import org.json.JSONObject;
import persistBanco.*;

@SuppressWarnings("resource")
public class socketServidor {
	public static void main(String args[]) {
		try {
			System.out.println("Servidor Pronto!!!");
			int serverPort = 14000; // the server port
			ServerSocket listenSocket = new ServerSocket(serverPort);
			while (true) {
				Socket clientSocket = listenSocket.accept();
				Connection c = new Connection(clientSocket);
				c.checkAccess();
			}
		} catch (IOException e) {
			System.out.println("Listen socket:" + e.getMessage());
		}
	}
}

class Connection extends Thread {
	DataInputStream in;
	DataOutputStream out;
	Socket clientSocket;
	metodos metodos = new metodos();
	controlaMetodos CM = new controlaMetodos();
	socketServidor SS = new socketServidor();
	JSONObject pacote = null;
	String data = "";

	public Connection(Socket aClientSocket) {
		try {
			clientSocket = aClientSocket;
			in = new DataInputStream(clientSocket.getInputStream());
			out = new DataOutputStream(clientSocket.getOutputStream());
			this.start();
		} catch (IOException e) {
			System.out.println("Connection:" + e.getMessage());
		}
	}

	public void run() {
		try {
			JSONObject resposta = CM.escolheMetodo(sendRespose());
			getRequest(resposta);
		} finally {
			try {
				clientSocket.close();
			} catch (IOException e) {
			}
		}

	}

	public JSONObject sendRespose() {
		try {
			pacote = new JSONObject(in.readUTF());

		} catch (EOFException e) {
			System.out.println("EOF:" + e.getMessage());
		} catch (IOException e) {
			System.out.println("readline:" + e.getMessage());
		}
		return pacote;
	}

	public void getRequest(JSONObject resposta) {
		try {
			out.writeUTF(resposta.toString());

		} catch (EOFException e) {
			System.out.println("EOF:" + e.getMessage());
		} catch (IOException e) {
			System.out.println("readline:" + e.getMessage());
		}
	}
}