package socket;

import java.net.*;
import java.io.*;

import org.json.JSONObject;

public class socketCliente {

	private Socket s = null;
	private JSONObject Pacote = new JSONObject();
	private int serverPort = 14000;

	public JSONObject getResponse() {
		try {

			DataInputStream in = new DataInputStream(s.getInputStream());
			Pacote = new JSONObject(in.readUTF());

		} catch (UnknownHostException e) {
			System.out.println("Socket:" + e.getMessage());
		} catch (EOFException e) {
			System.out.println("EOF:" + e.getMessage());
		} catch (IOException e) {
			System.out.println("readline:" + e.getMessage());
		}
		return Pacote;
	}

	public void sendRequest(JSONObject json) {
		try {

			s = new Socket("localhost", serverPort);
			DataOutputStream out = new DataOutputStream(s.getOutputStream());
			out.writeUTF(json.toString());

		} catch (UnknownHostException e) {
			System.out.println("Socket:" + e.getMessage());
		} catch (EOFException e) {
			System.out.println("EOF:" + e.getMessage());
		} catch (IOException e) {
			System.out.println("readline:" + e.getMessage());
		}
	}

	public void Close() {
		if (s != null)
			try {
				s.close();
			} catch (IOException e) {
				System.out.println("close:" + e.getMessage());
			}
	}
}
