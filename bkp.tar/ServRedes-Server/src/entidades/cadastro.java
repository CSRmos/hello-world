package entidades;

public class cadastro {

	int ID;
	String item;
	String descricao;
	int Matricula;
	int tipo;		// --tipo de cadastro == 1 - achou ou 2 - perdeu 
	int status;		// -- status == 1 - Entregue ao Dono, 2 - Ainda Com o Item e 3 - Entregue na Secretaria
	String local;	// -- local que o item foi encontrado
	String data;

	public cadastro() {
		// TODO Auto-generated constructor stub
	}

	public cadastro(int iD, String item, String descricao, int idUser,
			int tipo, int status, String local, String data) {
		this.ID = iD;
		this.item = item;
		this.descricao = descricao;
		this.Matricula = idUser;
		this.tipo = tipo;
		this.status = status;
		this.local = local;
		this.data = data;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getItem() {
		return item;
	}

	public void setItem(String item) {
		this.item = item;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getIdUser() {
		return Matricula;
	}

	public void setIdUser(int idUser) {
		this.Matricula = idUser;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "cadastro [ID=" + ID + ", item=" + item + ", descricao="
				+ descricao + ", idUser=" + Matricula + ", tipo=" + tipo
				+ ", status=" + status + ", local=" + local + ", data=" + data
				+ "]";
	}

}
