package entidades;

public class usuario {

	int matricula;
	String nome;
	int senha;
	String curso;
	int telefone;
	String email;

	public usuario(int matricula, String nome, int senha, String curso, int telefone, String email)
	{
		this.matricula = matricula;
		this.nome = nome;
		this.senha = senha;
		this.curso = curso;
		this.telefone = telefone;
		this.email = email;
	}

	public usuario() {
		// TODO Auto-generated constructor stub
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getSenha() {
		return senha;
	}

	public void setSenha(int senha) {
		this.senha = senha;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public int getTelefone() {
		return telefone;
	}

	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return matricula + " " + nome + " " + senha + " " + curso + 
				" " + telefone + " " + email;
	}

}
